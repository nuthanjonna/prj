var bal = angular.module('mySum', []);
bal.controller('summaryCtrl', function($scope,$http) {
    $scope.summarySheet= false;
	$scope.summaryForm =true;
	$scope.maindiv=true;
	$scope.navi=true;
	$scope.services=true;
	$scope.welcome=true;
	
	$scope.dsummary = function(accno,uname,pwd){
	//"http://localhost:8080/loginmodule/user/auth?email=k@k.com&pwd=xyz12"
	var url = "http://localhost:9090/loginmodule/rest/sum/dsummary?accno="+accno+"&uname="+uname+"&pwd="+pwd;
	console.log("##-----url--",url)
	$http({
	method: 'POST',
	url: url
		}).then(function successCallback(response) {
			console.log('hello1',response);
			
			$scope.result=response.data;
			
		
			$scope.summarySheet= true;
			$scope.summaryForm = false;
			$scope.navi=false;
			$scope.services=false;
			$scope.welcome=false;
			
		
		console.log(response);
		}, function errorCallback(response) {
		$scope.Status = 'Invalid user';
		});
	}
	
	$scope.wsummary = function(accno,uname,pwd){
		//"http://localhost:8080/loginmodule/user/auth?email=k@k.com&pwd=xyz12"
		var url = "http://localhost:9090/loginmodule/rest/sum/wsummary?accno="+accno+"&uname="+uname+"&pwd="+pwd;
		console.log("##-----url--",url)
		$http({
		method: 'POST',
		url: url
			}).then(function successCallback(response) {
				console.log('hello1',response);
				
				$scope.result=response.data;
				
			
				$scope.summarySheet= true;
				$scope.summaryForm = false;
				$scope.navi=false;
				$scope.services=false;
				$scope.welcome=false;
				
			
			console.log(response);
			}, function errorCallback(response) {
			$scope.Status = 'Invalid user';
			});
		}
	
	$scope.tsummary = function(accno,uname,pwd){
		//"http://localhost:8080/loginmodule/user/auth?email=k@k.com&pwd=xyz12"
		var url = "http://localhost:9090/loginmodule/rest/sum/tsummary?accno="+accno+"&uname="+uname+"&pwd="+pwd;
		console.log("##-----url--",url)
		$http({
		method: 'POST',
		url: url
			}).then(function successCallback(response) {
				console.log('hello1',response);
				
				$scope.result=response.data;
				
			
				$scope.summarySheet= true;
				$scope.summaryForm = false;
				$scope.navi=false;
				$scope.services=false;
				$scope.welcome=false;
				
			
			console.log(response);
			}, function errorCallback(response) {
			$scope.Status = 'Invalid user';
			});
		}
	
	});
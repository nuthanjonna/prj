package com.loginmodule.dao;

import com.loginmodule.model.Deposit;
import com.loginmodule.model.Withdraw;
import java.util.List;

public interface DepositDao {
	public int deposit(Deposit deposit);

	public int withdraw(Withdraw withdraw);

	public List<Deposit> findDepoByAccno(int accno);

	public List<Withdraw> findWithByAccno(int accno);

}

package com.loginmodule.service;

import java.security.MessageDigest;
import java.util.List;

import com.loginmodule.dao.NewaccDao;
import com.loginmodule.dao.NewaccDaoImpl;
import com.loginmodule.model.Newacc;
import com.loginmodule.model.Transfer;

public class NewaccServiceImpl implements NewaccService {

	NewaccDao newaccDao = new NewaccDaoImpl();

	public int newacc(Newacc newacc) {

		int accountno = newaccDao.newacc(newacc);
		return accountno;
	}

	public int findUserByAccno(int accno) {

		return newaccDao.findUserByAccno(accno);
	}

	@Override
	public int transfer(Transfer transfer) {
		int tid = newaccDao.transfer(transfer);
		return tid;
	}

	@Override
	public List<Transfer> findTransByAccno(int accno) {
		
		return newaccDao.findTransByAccno(accno) ;
	}
	
	@Override
    public String Md5Encrypt(String data) throws Exception {
        byte[] passwordInByte = data.getBytes("UTF-8");
        MessageDigest messageDigest = MessageDigest.getInstance("MD5");
        byte[] digestPassword = messageDigest.digest(passwordInByte);
        String encryptPassword = "";
        for (int i = 0; i < digestPassword.length; i++) {
            encryptPassword += Integer.toString((digestPassword[i] & 
0xff) + 0x100, 16).substring(1);
        }
        return encryptPassword;
    };
}

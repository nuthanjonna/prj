package com.loginmodule.dao;

import java.util.List;

import org.hibernate.Query;

import com.loginmodule.model.Deposit;
import com.loginmodule.model.Newacc;
import com.loginmodule.model.Transfer;
import com.loginmodule.model.Withdraw;
import com.loginmodule.util.HibernateUtil;

public class NewaccDaoImpl implements NewaccDao {

	Newacc newacc = new Newacc();
	Deposit deposit = new Deposit();
	Transfer transfer = new Transfer();
	Withdraw withdraw = new Withdraw();
	HibernateUtil hibernateUtil = new HibernateUtil();
	
	
	//To create a new bank account with auto generated account number
	@Override
	public int newacc(Newacc newacc) {

		hibernateUtil.openCurrentSessionWithTransaction();
		int cid = (int) hibernateUtil.getCurrentSession().save(newacc);
		hibernateUtil.closeCurrentSessionwithTransaction();
		return cid;

	}
	
	
	//To check the available balance of a account holder with reference to the account number.
	@Override
	public int findUserByAccno(int accno) {
		hibernateUtil.openCurrentSession();

		int avl_bal = (int) hibernateUtil.getCurrentSession()
				.createQuery("select amount from Newacc where accountno= '" + accno + "'").uniqueResult();

		hibernateUtil.closeCurrentSession();

		return avl_bal;

	}
	
	
	//To transfer amount from one account to another account
	@Override
	public int transfer(Transfer transfer) {
		hibernateUtil.openCurrentSessionWithTransaction();
		//To save the transfer details in transfer table
		int tid = (int) hibernateUtil.getCurrentSession().save(transfer);

		int sourcebal = (int) hibernateUtil.getCurrentSession()
				.createQuery("select amount from Newacc where accountno= '" + transfer.getAccno() + "'").uniqueResult();
		Query query = hibernateUtil.getCurrentSession()
				.createQuery("update Newacc set amount=:debitAmount where accountno='" + transfer.getAccno() + "'");
		query.setParameter("debitAmount", sourcebal - transfer.getAmount());
		query.executeUpdate();
		System.out.println("Debit Updated!");

		int destbal = (int) hibernateUtil.getCurrentSession()
				.createQuery("select amount from Newacc where accountno= '" + transfer.getTaccno() + "'")
				.uniqueResult();
		Query query1 = hibernateUtil.getCurrentSession()
				.createQuery("update Newacc set amount=:creditAmount where accountno='" + transfer.getTaccno() + "'");
		query1.setParameter("creditAmount", transfer.getAmount() + destbal);
		query1.executeUpdate();
		System.out.println("Credit Updated!");

		hibernateUtil.closeCurrentSessionwithTransaction();
		return tid;

	}

	@Override
	public List<Transfer> findTransByAccno(int accno) {
		hibernateUtil.openCurrentSession();

		@SuppressWarnings("unchecked")
		List<Transfer> transfer = (List<Transfer>) hibernateUtil.getCurrentSession()
				.createQuery("from Transfer where accountno= '" + accno + "'").list();

		hibernateUtil.closeCurrentSession();
		return transfer;
	}

}

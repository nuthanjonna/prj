package com.loginmodule.controller;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.codehaus.jettison.json.JSONObject;

import com.loginmodule.model.Newacc;
import com.loginmodule.service.NewaccService;
import com.loginmodule.service.NewaccServiceImpl;

@Path("/user2")
public class NewaccController {

	

	@Path("/newacc")
	@POST
	@Produces("text/html")
	public String newacc(@QueryParam("uname") String uname, @QueryParam("pwd") String pwd,
			@QueryParam("repwd") String repwd, @QueryParam("amount") int amount, @QueryParam("address") String address,
			@QueryParam("phone") double phone, @QueryParam("pin") int pin) throws Exception {
		System.out.println("hello");
		NewaccService newaccService = new NewaccServiceImpl();
		String newpwd = newaccService.Md5Encrypt(pwd);
		Newacc newacc = new Newacc();

		newacc.setUname(uname);
		newacc.setPwd(newpwd);
		/* newacc.setRepwd(repwd); */
		newacc.setAmount(amount);
		newacc.setAddress(address);
		newacc.setPhone(phone);
		newacc.setPin(pin);
	
		int accountno = newaccService.newacc(newacc);

		String response = "";
		JSONObject jsonObject = new JSONObject();

		jsonObject.put("Status", "Success");
		jsonObject.put("uname", uname);
		jsonObject.put("accno", accountno);

		response = jsonObject.toString();

		return response;
	}

}

package com.loginmodule.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "account")
public class Newacc {

	@Id
	@GeneratedValue
	@Column(name = "accountno")
	private int accountno;

	@Column(name = "uname")
	private String uname;

	@Column(name = "pwd")
	private String pwd;

	@Column(name = "repwd")
	private String repwd;

	@Column(name = "amount")
	private int amount;

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	@Column(name = "address")
	private String address;

	@Column(name = "phone")
	private double phone;

	@Column(name = "pin")
	private int pin;

	public int getUserId() {
		return accountno;
	}

	public void setUid(int UserId) {
		this.accountno = UserId;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getRepwd() {
		return repwd;
	}

	public void setRepwd(String repwd) {
		this.repwd = repwd;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public double getPhone() {
		return phone;
	}

	public void setPhone(double phone) {
		this.phone = phone;
	}

}

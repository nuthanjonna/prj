var bal = angular.module('myWdraw', []);
bal.controller('withdrawCtrl', function($scope,$http) {
    $scope.WithdrawSheet= false;
	$scope.withdrawForm =true;
	
	
	
	$scope.withdraw = function(accountno,username,date,amount){
	//"http://localhost:8080/loginmodule/user/auth?email=k@k.com&pwd=xyz12"
	var url = "http://localhost:9090/loginmodule/rest/with/withdraw?accountno="+accountno+"&username="+username+"&date="+date+"&amount="+amount;
	console.log("##-----url--",url)
	$http({
	method: 'POST',
	url: url
		}).then(function successCallback(response) {
			console.log('hello1',response);
			
			$scope.accountno = response.data.accno;
			$scope.name = response.data.uname;
			$scope.amount = response.data.amount;
			$scope.balance= response.data.avlbal;
			
			
			$scope.WithdrawSheet= true;
			$scope.withdrawForm = false;
		
		console.log(response);
		}, function errorCallback(response) {
		$scope.Status = 'Invalid user';
		});
	}
	});
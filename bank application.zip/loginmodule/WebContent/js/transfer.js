var bal = angular.module('myTrans', []);
bal.controller('transferCtrl', function($scope,$http) {
    $scope.transferSheet= false;
	$scope.transferForm =true;
	
	
	
	$scope.transfer = function(accountno,username,pin,taccountno,amount){
	//"http://localhost:8080/loginmodule/user/auth?email=k@k.com&pwd=xyz12"
var url = "http://localhost:9090/loginmodule/rest/trans/transfer?accountno="+accountno+"&username="+username+"&pin="+pin+"&taccountno="+taccountno+"&amount="+amount;
	console.log("##-----url--",url)
	$http({
	method: 'POST',
	url: url
		}).then(function successCallback(response) {
			console.log('hello1',response);
			/*if(response =='Success'){*/
			
			$scope.taccountno = response.data.taccno;
			$scope.tid = response.data.transid;
			$scope.amount = response.data.amount;
			
			$scope.transferSheet= true;
			$scope.transferForm = false;
			/*} else {
				console.log('hello2');
			$scope.Status = 'Invalid user';
			}*/
		
		console.log(response);
		}, function errorCallback(response) {
		$scope.Status = 'Invalid user';
		});
	}
	});
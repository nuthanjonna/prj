var bal = angular.module('myDep', []);
bal.controller('depositCtrl', function($scope,$http) {
    $scope.DepositSheet= false;
	$scope.depositForm =true;
	
	$scope.depo = function(accountno,username,date,amount){
	//"http://localhost:8080/loginmodule/user/auth?email=k@k.com&pwd=xyz12"
	var url = "http://localhost:9090/loginmodule/rest/user1/deposit?accountno="+accountno+"&username="+username+"&date="+date+"&amount="+amount;
	console.log("##-----url--",url)
	$http({
	method: 'POST',
	url: url
		}).then(function successCallback(response) {
			console.log('hello1',response);
			
			$scope.accountno = response.data.accno;
			$scope.name = response.data.uname;
			$scope.amount = response.data.amount;
			
			$scope.DepositSheet= true;
			$scope.depositForm = false;
			
		
		console.log(response);
		}, function errorCallback(response) {
		$scope.Status = 'Invalid user';
		});
	}
	});
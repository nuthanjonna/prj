package com.loginmodule.dao;

import java.util.List;

import org.hibernate.Query;

import com.loginmodule.model.Deposit;
import com.loginmodule.model.Withdraw;
import com.loginmodule.util.HibernateUtil;



public class DepositDaoImpl implements DepositDao {

	HibernateUtil hibernateUtil = new HibernateUtil();
	Deposit deposit = new Deposit();
	Withdraw withdraw = new Withdraw();

	@Override
	public int deposit(Deposit deposit) {
		
		//To save deposit details in deposit table and to update the deposited amount in account(main) table
		hibernateUtil.openCurrentSessionWithTransaction();
		int did = (int) hibernateUtil.getCurrentSession().save(deposit);
		int cur_amt = (int) hibernateUtil.getCurrentSession()
				.createQuery("select amount from Newacc where accountno= '" + deposit.getAccno() + "'").uniqueResult();
		Query query = hibernateUtil.getCurrentSession()
				.createQuery("update Newacc set amount=:newAmount where accountno='" + deposit.getAccno() + "'");

		query.setParameter("newAmount", deposit.getAmount() + cur_amt);
		query.executeUpdate();

		System.out.println("Updated!");

		hibernateUtil.closeCurrentSessionwithTransaction();
		return did;

	}

	//To save withdraw details in withdraw table and to update the withdrawn amount in account(main) table
	@Override
	public int withdraw(Withdraw withdraw) {
		hibernateUtil.openCurrentSessionWithTransaction();
		int wid = (int) hibernateUtil.getCurrentSession().save(withdraw);
		int curr_amt = (int) hibernateUtil.getCurrentSession()
				.createQuery("select amount from Newacc where accountno= '" + withdraw.getAccno() + "'").uniqueResult();
		Query query = hibernateUtil.getCurrentSession()
				.createQuery("update Newacc set amount=:newAmount where accountno='" + withdraw.getAccno() + "'");

		query.setParameter("newAmount", curr_amt - withdraw.getAmount());
		query.executeUpdate();
		System.out.println("Updated!");
		hibernateUtil.closeCurrentSessionwithTransaction();
		return curr_amt;
	}
	
	
    //To get the summary of deposits made with reference to the account number
	@Override
	public List<Deposit> findDepoByAccno(int accno) {

		hibernateUtil.openCurrentSession();

		@SuppressWarnings("unchecked")
		List<Deposit> deposit = (List<Deposit>) hibernateUtil.getCurrentSession()
				.createQuery("from Deposit where accountno= '" + accno + "'").list();

		hibernateUtil.closeCurrentSession();
		return deposit;
	}
	
	
	 //To get the summary of withdraw made with reference to the account number
	@Override
	public List<Withdraw> findWithByAccno(int accno) {
		hibernateUtil.openCurrentSession();

		@SuppressWarnings("unchecked")
		List<Withdraw> withdraw = (List<Withdraw>) hibernateUtil.getCurrentSession()
				.createQuery("from Withdraw where accountno= '" + accno + "'").list();

		hibernateUtil.closeCurrentSession();
		return withdraw;
	}

}

package com.loginmodule.dao;

import java.util.List;

import com.loginmodule.model.Newacc;
import com.loginmodule.model.Transfer;

public interface NewaccDao {

	public int newacc(Newacc newacc);

	public int findUserByAccno(int accno);

	public int transfer(Transfer transfer);

	public List<Transfer> findTransByAccno(int accno);

}

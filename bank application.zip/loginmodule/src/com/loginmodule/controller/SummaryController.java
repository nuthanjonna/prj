package com.loginmodule.controller;

import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;


import com.loginmodule.model.Deposit;
import com.loginmodule.model.Transfer;
import com.loginmodule.model.Withdraw;
import com.loginmodule.service.DepositService;
import com.loginmodule.service.DepositServiceImpl;
import com.loginmodule.service.NewaccService;
import com.loginmodule.service.NewaccServiceImpl;

@Path("/sum")
public class SummaryController {

	


	@Path("/dsummary")
	@POST
	@Produces("application/json")
	public List<Deposit> dsummary(@QueryParam("accno") int accno, @QueryParam("uname") String uname,
			@QueryParam("pwd") String pwd) throws Exception {
		DepositService depositService = new DepositServiceImpl();
		return depositService.findDepoByAccno(accno);

	}

	@Path("/wsummary")
	@POST
	@Produces("application/json")
	public List<Withdraw> wsummary(@QueryParam("accno") int accno, @QueryParam("uname") String uname,
			@QueryParam("pwd") String pwd) throws Exception {
		DepositService depositService = new DepositServiceImpl();
		return depositService.findWithByAccno(accno);

	}

	@Path("/tsummary")
	@POST
	@Produces("application/json")
	public List<Transfer> tsummary(@QueryParam("accno") int accno, @QueryParam("uname") String uname,
			@QueryParam("pwd") String pwd) throws Exception {
		NewaccService newaccService = new NewaccServiceImpl();
		return newaccService.findTransByAccno(accno);

	}
}

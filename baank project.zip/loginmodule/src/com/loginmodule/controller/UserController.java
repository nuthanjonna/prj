package com.loginmodule.controller;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.codehaus.jettison.json.JSONObject;

import com.loginmodule.model.User;
import com.loginmodule.service.UserService;
import com.loginmodule.service.UserServiceImpl;
import com.sun.jersey.multipart.FormDataParam;

@Path("/user")
public class UserController {

	

	@Path("/auth")
	@GET
	@Produces("text/html")
	public String authUserByEmail(@QueryParam("email") String email, @QueryParam("pwd") String pwd) throws Exception {
		UserService userService = new UserServiceImpl();
		User user = userService.findUserByEmail(email);

		String response = "";
		JSONObject jsonObject = new JSONObject();

		if (email.equalsIgnoreCase(user.getEmail()) && pwd.equalsIgnoreCase(user.getPwd())) {

			jsonObject.put("Status", "Success");
			jsonObject.put("name", user.getName());
			jsonObject.put("email", user.getEmail());
			jsonObject.put("uid", user.getUserId());

			response = jsonObject.toString();

		} else {

			jsonObject.put("Status", "Failure");
			response = jsonObject.toString();

		}

		return response;
	}

	@Path("/save")
	@POST
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces("text/html")
	public String saveUser(@FormDataParam("userName") String userName, @FormDataParam("email") String email,
			@FormDataParam("password") String password) {
		System.out.println("hello");

		User user = new User();
		user.setName(userName);
		user.setEmail(email);
		user.setPwd(password);
		user.setIsActive(1);
		UserService userService = new UserServiceImpl();
		int uid = userService.saveUser(user);

		return "User Successfully saved with uid :" + uid;
	}

	public static void main(String args[]) {
		System.out.println(new UserServiceImpl().findUserByEmail("p@p.com").getName());
	}

}

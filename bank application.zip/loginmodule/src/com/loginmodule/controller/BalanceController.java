package com.loginmodule.controller;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.codehaus.jettison.json.JSONObject;


import com.loginmodule.service.NewaccService;
import com.loginmodule.service.NewaccServiceImpl;

@Path("/bal")
public class BalanceController {


	
	@Path("/balance")
	@POST
	@Produces("text/html")
	public String authUserByName(@QueryParam("accno") int accno, @QueryParam("uname") String uname,
			@QueryParam("pwd") String pwd) throws Exception {
		
		NewaccService newaccService = new NewaccServiceImpl();
		int newacc = newaccService.findUserByAccno(accno);

		String response = "";
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("Status", "Success");
		jsonObject.put("uname", uname);
		jsonObject.put("pwd", pwd);
		jsonObject.put("accountno", accno);
		jsonObject.put("amount", newacc);

		response = jsonObject.toString();

		return response;
	}
}

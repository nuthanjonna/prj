package com.loginmodule.service;

import java.util.List;

import com.loginmodule.dao.DepositDao;
import com.loginmodule.dao.DepositDaoImpl;
import com.loginmodule.model.Deposit;
import com.loginmodule.model.Withdraw;

public class DepositServiceImpl implements DepositService {

	DepositDao depositDao = new DepositDaoImpl();

	public int deposit(Deposit deposit) {

		int did = depositDao.deposit(deposit);
		return did;
	}

	public int withdraw(Withdraw withdraw) {

		int Wid = depositDao.withdraw(withdraw);
		return Wid;
	}

	public List<Deposit> findDepoByAccno(int accno) {

		return depositDao.findDepoByAccno(accno);
	}

	
	public List<Withdraw> findWithByAccno(int accno) {
		
		return  depositDao.findWithByAccno(accno);
	}

	
	
}

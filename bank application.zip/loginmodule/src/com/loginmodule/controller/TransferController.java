package com.loginmodule.controller;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import org.codehaus.jettison.json.JSONObject;

import com.loginmodule.model.Transfer;

import com.loginmodule.service.NewaccService;
import com.loginmodule.service.NewaccServiceImpl;

@Path("/trans")
public class TransferController {



	@Path("/transfer")
	@POST
	@Produces("text/html")

	public String withdraw(@QueryParam("accountno") int accountno, @QueryParam("username") String username,
			@QueryParam("pin") int pin, @QueryParam("taccountno") int taccountno, @QueryParam("amount") int amount)
			throws Exception {
		System.out.println("hello");
		Transfer transfer = new Transfer();
		transfer.setAccno(accountno);
		transfer.setUname(username);
		transfer.setPin(pin);
		transfer.setTaccno(taccountno);
		transfer.setAmount(amount);
		NewaccService newaccService = new NewaccServiceImpl();
		int tid = newaccService.transfer(transfer);

		String response = "";
		JSONObject jsonObject = new JSONObject();

		jsonObject.put("Status", "Success");
		jsonObject.put("uname", username);
		jsonObject.put("taccno", taccountno);
		jsonObject.put("transid", tid);
		jsonObject.put("amount", amount);

		response = jsonObject.toString();

		return response;

	}

}

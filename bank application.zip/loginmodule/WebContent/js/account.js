var bal = angular.module('myAcc', []);
bal.controller('accountCtrl', function($scope, $http) {
	/*
	 * $scope.ph_numbr = /^\+?\d{10}$/; $scope.eml_add =
	 * /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
	 */
	$scope.AccountSheet = false;
	$scope.accountForm = true;

	$scope.newacc = function(uname, pwd, repwd, amount, address, phone, pin) {
		// "http://localhost:8080/loginmodule/user/auth?email=k@k.com&pwd=xyz12"
		var url = "http://localhost:9090/loginmodule/rest/user2/newacc?uname="
				+ uname + "&pwd=" + pwd + "&repwd=" + repwd + "&amount="
				+ amount + "" + "&address=" + address + "&phone=" + phone
				+ "&pin=" + pin;
		console.log("##-----url--", url)
		$http({
			method : 'POST',
			url : url
		}).then(function successCallback(response) {
			console.log('hello1', response);

			$scope.accountno = response.data.accno;
			$scope.name = response.data.uname;

			$scope.AccountSheet = true;
			$scope.accountForm = false;

			console.log(response);
		}, function errorCallback(response) {
			$scope.Status = 'Invalid user';
		});
	}

});
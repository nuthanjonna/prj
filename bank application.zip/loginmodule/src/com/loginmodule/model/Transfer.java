package com.loginmodule.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transfer")
public class Transfer {

	@Id
	@GeneratedValue
	@Column(name = "tid")
	private int tid;

	@Column(name = "accountno")
	private int accno;

	@Column(name = "username")
	private String uname;

	@Column(name = "pin")
	private int pin;

	@Column(name = "taccountno")
	private int taccno;

	@Column(name = "amount")
	private int amount;

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public int getTaccno() {
		return taccno;
	}

	public void setTaccno(int taccno) {
		this.taccno = taccno;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}

package com.loginmodule.service;

import java.util.List;

import com.loginmodule.model.Deposit;
import com.loginmodule.model.Withdraw;

public interface DepositService {

	public int deposit(Deposit deposit);

	public int withdraw(Withdraw withdraw);

	public List<Deposit> findDepoByAccno(int accno);

	public List<Withdraw> findWithByAccno(int accno);



}

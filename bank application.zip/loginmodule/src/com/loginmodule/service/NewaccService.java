package com.loginmodule.service;

import java.util.List;

import com.loginmodule.model.Newacc;
import com.loginmodule.model.Transfer;

public interface NewaccService {

	public int newacc(Newacc newacc);

	public int findUserByAccno(int accno);

	public int transfer(Transfer transfer);

	public List<Transfer> findTransByAccno(int accno);
	
	String Md5Encrypt(String data) throws Exception;

}

package com.loginmodule.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "deposit")
public class Deposit {

	@Id
	@GeneratedValue
	@Column(name = "did")
	private int did;

	@Column(name = "accountno")
	private int accno;

	@Column(name = "username")
	private String uname;

	@Column(name = "date")
	private String date;

	@Column(name = "amount")
	private int amount;

	public int getUserId() {
		return did;
	}

	public void setUid(int DepositId) {
		this.did = DepositId;
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}

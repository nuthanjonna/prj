package com.loginmodule.controller;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import org.codehaus.jettison.json.JSONObject;

import com.loginmodule.model.Withdraw;
import com.loginmodule.service.DepositService;
import com.loginmodule.service.DepositServiceImpl;

@Path("/with")
public class WithdrawController {

	

	@Path("/withdraw")
	@POST

	@Produces("text/html")

	public String withdraw(@QueryParam("accountno") int accountno, @QueryParam("username") String username,
			@QueryParam("date") String date, @QueryParam("amount") int amount) throws Exception {
		
		System.out.println("hello");
		
		Withdraw withdraw = new Withdraw();
		withdraw.setAccno(accountno);
		withdraw.setUname(username);
		withdraw.setDate(date);
		withdraw.setAmount(amount);
		
		DepositService depositService = new DepositServiceImpl();
		int wid = depositService.withdraw(withdraw);
		
		String response = "";
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("Status", "Success");
		jsonObject.put("uname", username);
		jsonObject.put("accno", accountno);
		jsonObject.put("avlbal", wid);
		jsonObject.put("amount", amount);

		response = jsonObject.toString();

		return response;

	}

}

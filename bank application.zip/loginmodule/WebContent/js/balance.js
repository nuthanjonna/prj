var bal = angular.module('myBal', []);
bal.controller('balanceCtrl', function($scope,$http) {
    $scope.BalanceSheet= false;
	$scope.balanceForm =true;
	
	
	$scope.check = function(accno, uname, pwd){
	//"http://localhost:8080/loginmodule/user/auth?email=k@k.com&pwd=xyz12"
	var url = "http://localhost:9090/loginmodule/rest/bal/balance?accno="+accno+"&uname="+uname+"&pwd="+pwd;
	console.log("##-----url--",url)
	$http({
	method: 'POST',
	url: url
		}).then(function successCallback(response) {
			console.log('hello1', response);
			
		$scope.accountno = response.data.accountno;
		$scope.name = response.data.uname;
		$scope.balance = response.data.amount;
	
		$scope.BalanceSheet= true;
		$scope.balanceForm = false;
			
		
		console.log(response);
		}, function errorCallback(response) {
		$scope.Status = 'Invalid user';
		});
	}
	});